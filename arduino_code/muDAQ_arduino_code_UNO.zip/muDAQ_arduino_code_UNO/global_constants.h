/*
   TEMPLATE
   Created:       2022-05-09
   Last Modified: 2022-05-16
   By: Joseph Lewis-Merrill

   Description:
      Contains global constants used throughout the muDAQ program
*/
#ifndef GLOBAL_CONSTANTS_H_INCLUDED
#define GLOBAL_CONSTANTS_H_INCLUDED

#include <Arduino.h>

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const unsigned long DEFAULT_BAUDRATE = 230400;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const unsigned long DEFAULT_SERIAL_DELAY = 1;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const byte DEFAULT_CONNECT_BYTE = 0x11;
const byte DEFAULT_RESTART_BYTE = 0xDD;
const byte DEFAULT_CONFIRM_BYTE = 0xEE;
const byte DEFAULT_REJECT_BYTE = 0xFF;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const int DEFAULT_RESTART_COUNT = 4;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const int READ_RESOLUTION = 10;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const String VAL_SEPARATOR = ",";
const String CH_SEPARATOR = ";";
const String MSG_TERMINATOR = "\r\n";

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const byte MIN_VALID_PIN_COUNT = 0x01;
const byte MAX_VALID_PIN_COUNT = 0xFF;

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const int VALID_PINS[] = {
    A0, A1, A2, A3, A4, A5
//  A11,
//  A12,
//  A13,
//  A16,
//  A29,
//  A31,
//  A32,
//  A33,
//  A34,
//  A35
};

/*--------------------------------------------------
   TEMPLATE
    TEMPLATE
  --------------------------------------------------
*/
const int NUM_VALID_PINS = (int)(sizeof(VALID_PINS) / sizeof(VALID_PINS[0]));

#endif
