/*
 * base_fncs.cpp
 * Created:       2022-05-09
 * Last Modified: 2022-05-16
 * By: Joseph Lewis-Merrill
 * 
 * Description:
 *    Contains base-level functions use throughout the muDAQ program.
 */

#include <Arduino.h>
#include "global_constants.h"

/*--------------------------------------------------
 * Type: Module Variable
 * bool led_initialized
 *  Used by led_on() and led_off() to check if
 *    LED has been initialized yet. If not, calls
 *    initialize_led(), which sets it to true.
 *--------------------------------------------------
 */
bool led_initialized = false;

/*--------------------------------------------------
 * Type: Function
 * void initialize_led()
 *  Prepares the builtin LED for use.
 *  
 *  Arguments:
 *    None
 *    
 *  Returns
 *    void
 *--------------------------------------------------
 */
void initialize_led() {
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);
}

/*--------------------------------------------------
 * Type: Function
 * void led_on()
 *  Sets the builtin LED to HIGH (on)
 *  
 *  Arguments:
 *    None
 *    
 *  Returns
 *    void
 *--------------------------------------------------
 */
void led_on() {
  if (!led_initialized) {
    initialize_led();
  }
  digitalWrite(LED_BUILTIN, HIGH);
}

/*--------------------------------------------------
 * Type: Function
 * void led_off()
 *  Sets the builtin LED to LOW (off)
 *  
 *  Arguments:
 *    None
 *    
 *  Returns
 *    TEMPLATE
 *--------------------------------------------------
 */
void led_off() {
  if (!led_initialized) {
    initialize_led();
  }
  digitalWrite(LED_BUILTIN, LOW);
  
}

/*--------------------------------------------------
 * Type: Function
 * bool byte_in_range_incl()
 *  Check if test_byte is in between low_byte and 
 *    high_byte inclusively.
 *  
 *  Arguments:
 *    byte test_byte -> byte to check
 *    byte low_byte  -> lower bound [incl.]
 *    byte high_byte -> upper bound [incl.]
 *  
 *  Returns 
 *    true if in range
 *    false otherwise
 *--------------------------------------------------
 */
bool byte_in_range_incl(
  byte test_byte, 
  byte low_byte, 
  byte high_byte
  ) {
    
  if ((test_byte <= high_byte) && (test_byte >= low_byte)) {
    return true;
  }
  else {
    return false;
  }
  
}
/*--------------------------------------------------
 * Type: Function
 * bool byte_in_range_excl()
 *  Check if test_byte is in between low_byte and 
 *    high_byte exclusively
 *  
 *  Arguments:
 *    byte test_byte -> byte to check
 *    byte low_byte  -> lower bound [excl.]
 *    byte high_byte -> upper bound [excl.]
 *  
 *  Returns 
 *    true if in range
 *    false otherwise
 *--------------------------------------------------
 */
bool byte_in_range_excl(
  byte test_byte, 
  byte low_byte, 
  byte high_byte
  ) {
    
  if ((test_byte < high_byte) && (test_byte > low_byte)) {
    return true;
  }
  else {
    return false;
  }
  
}

/*--------------------------------------------------
 * Type: Function
 * bool int_in_array()
 *  Checks if test_int is the same as any values in
 *    the const int array given by array_pointer
 *  Used by get_single_pin_val() in 
 *    initialization_fncs.cpp to validate pins
 *  
 *  Arguments:
 *    int test_int             -> value to check
 *    int array_length         -> length of array
 *    const int* array_pointer -> pointer to array
 *    
 *  Returns 
 *    true if test_int is found
 *    false otherwise
 *--------------------------------------------------
 */
bool int_in_array(
  int test_int,
  int array_length,
  const int* array_pointer
  ) {
    
  for (int i = 0; i < array_length; i++) {
    if (test_int == array_pointer[i]) {
      return true; 
    }
  }
  return false;
    
}

/*--------------------------------------------------
 * Type: Function
 * bool* initialize_bool_array()
 *  Creates a new 
 *  
 *  Arguments:
 *    TEMPLATE ->
 *    
 *  Returns
 *    TEMPLATE
 *--------------------------------------------------
 */
bool* initialize_bool_array(int array_length) {
  bool* bool_array = new bool[array_length];
  for (int i = 0; i < array_length; i++) {
    bool_array[i] = false;
  }
  return bool_array;
}

/*--------------------------------------------------
 * Type: TEMPLATE
 * TEMPLATE
 *  TEMPLATE
 *  
 *  Arguments:
 *    TEMPLATE ->
 *    
 *  Returns
 *    TEMPLATE
 *--------------------------------------------------
 */
int* initialize_int_array(int array_length) {
  int* int_array = new int[array_length];
  for (int i = 0; i<array_length; i++) {
    int_array[i] = 0;
  }
  return int_array;
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
unsigned long* initialize_ulong_array(int array_length) {
  unsigned long* ulong_array = new unsigned long[array_length];
  for (int i = 0; i<array_length; i++) {
    ulong_array[i] = 0;
  }
  return ulong_array;
  
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
float LOG_BASE_CONSTANT = 1/log(float(256));

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
int num_bytes_for_bytestring (unsigned long input_ulong) {
  int num_bytes = 0;
  if (input_ulong == 0 || input_ulong == 1){
    num_bytes = 1;
  }
  else {
    num_bytes = ceil(log(input_ulong)*LOG_BASE_CONSTANT);
    if (num_bytes < 1) {
      num_bytes = 1;
    }
  }
  return num_bytes;
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
void parse_ulong_into_bytes(
  unsigned long input_ulong, 
  int num_bytes,
  byte* byte_array
  ){

  unsigned long rem = 0;
  unsigned long num = input_ulong;

  

//  byte* byte_array = new byte[num_bytes];
  for (int i = 0; i < num_bytes; i++) {
    byte_array[i] = 0x00;
  }

  for (int byte_index = num_bytes - 1; byte_index >= 0; byte_index--) {
    rem = num % 256;
    byte_array[byte_index] = byte(rem);
    num = (num-rem) / 256;
  }
  
//  return byte_array;
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
void serial_write_ulong(unsigned long input_ulong) {
  int num_bytes = num_bytes_for_bytestring(input_ulong);
  byte byte_array[num_bytes];
  parse_ulong_into_bytes(
    input_ulong, 
    num_bytes,
    byte_array
    );
  for (int i = 0; i < num_bytes; i++) {
    Serial.write(byte_array[i]);
  }
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
const unsigned long ULONG_BASE_CONSTANTS[] = {
  1,
  256,
  65536,
  16777216,
//  4294967296,
//  1099511627776,
//  281474976710656,
//  72057594037927936,
};

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
unsigned long get_val_from_serial_by_count(
  int byte_count,
  int serial_delay = DEFAULT_SERIAL_DELAY,
  bool big_endian = true
  ) {

  byte byte_array[byte_count];
  for (int i = 0; i < byte_count; i++) {
    byte_array[i] = 0;
  }
  
  while (!(Serial.available() >= byte_count)) {
    delay(serial_delay);
  }

  for (int i = 0; i < byte_count; i++) {
    byte_array[i] = Serial.read();
  }

  unsigned long ret_val = 0;
  int index = 0;
  unsigned long multiplier_val = 0;
  unsigned long addendum = 0;
  for (int i = 0; i < byte_count; i++) {
    if (big_endian) {
      index = byte_count - i - 1;
    }
    else {
      index = i;
    }
    multiplier_val = (unsigned long)(byte_array[i]);
    addendum = (ULONG_BASE_CONSTANTS[index] * multiplier_val);
    ret_val += addendum;
  
  }
  for (int i = 0; i < byte_count; i++) {
    Serial.print(byte_array[i], HEX);
    Serial.print(".");
  }
  Serial.print(",");
  Serial.println(ret_val);
  return ret_val;
}

/*--------------------------------------------------
 * TEMPLATE
 *  TEMPLATE
 *--------------------------------------------------
 */
bool duration_elapsed(
  unsigned long last_micros, 
  unsigned long now_micros, 
  unsigned long duration
  ) {

    unsigned long elapsed = 0;
    if (now_micros < last_micros) {
      // Rollover has occurred!
      elapsed = (4294967295 - last_micros) + now_micros;
    }
    else {
      elapsed = now_micros - last_micros;
    }

    if (elapsed >= duration) {
      return true;
    }
    else {
      return false;
    }
}
  
