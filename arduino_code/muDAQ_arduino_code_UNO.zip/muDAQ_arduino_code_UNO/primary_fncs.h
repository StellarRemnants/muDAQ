/*
 * TEMPLATE
 * Created:       2022-05-09
 * Last Modified: 2022-05-16
 * By: Joseph Lewis-Merrill
 * 
 * Description: 
 *    Contains declarations for functions in primary_fncs.cpp
 */

#include "global_constants.h"
struct daq_settings setup_loop();
bool main_loop(struct daq_settings* global_daq_settings);
